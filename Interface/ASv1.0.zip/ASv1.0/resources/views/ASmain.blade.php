@extends('layouts.app')

@section('content')
    <!-- Bootstrap Boilerplate... --> 
    <div class="container">
    <div class="col-sm-offset-2 col-sm-8">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h1>Single sample acquisition</h1>
            </div>

    <div class="panel-body">
        An easy to use acquisition system based on Derek Molloy's ADC example.
        <br><br>
        Follow the next steps to aquire a 6 seconds sample with 2 KHz sampling frequency
        <br><br>
        <!-- Display Validation Errors -->
        @include('common.errors')

        <!--1st Step in Acquisition process-->
        <h2>First Step. Configuration</h2>
        <br>
        The first step consist in the BeagleBone configuration.
        <br><br>

        <!-- Execute 1st Step-->
        <div class="form-group">
            <label for="task" class="col-sm-3 control-label" >First step</label>
            <div class="col-sm-offset-3 col-sm-6">
                <button type="submit" class="btn btn-primary" onclick="buttonExecuteClicked('ls -la')">
                    <i class="fa fa-rocket aria-hidden="true""></i>  Execute
                </button>
            </div>
        </div>

        <div class="form-group">
            <br><br>
            <pre id="labelCommandID"> No se ha ejecutado el comando</pre>
        </div>
    </div>

    <script type="text/javascript">

        function commandExecuted(resultText) {
            console.log(resultText);
            // document.getElementById('labelCommandID').innerHTML = resultText;
            $('#labelCommandID').html(resultText);
        }

        function buttonExecuteClicked(command) {
            $('#labelCommandID').html("Loading...");
            // var command = "ls -la";
            command = encodeURI(command);
            sendAsyncGetRequest('/command/' + command, commandExecuted);
        }

        function sendAsyncGetRequest(requestString,doOnDone)
        {
            var xmlhttp;
            if (window.XMLHttpRequest)
            {// code for IE7+, Firefox, Chrome, Opera, Safari
                xmlhttp=new XMLHttpRequest();
            }
            else
            {// code for IE6, IE5
                xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange=function()
            {
                if (xmlhttp.readyState==4 && xmlhttp.status==200)
                {
                    doOnDone(xmlhttp.responseText);
                }
            }
            xmlhttp.open("GET",requestString,true);
            xmlhttp.send();
        }
    </script>

@endsection
